package cash.z.ecc.android.sdk

import android.content.Context
import cash.z.ecc.android.sdk.Synchronizer.Companion.new
import cash.z.ecc.android.sdk.WalletInitMode.RestoreWallet
import cash.z.ecc.android.sdk.block.processor.CompactBlockProcessor
import cash.z.ecc.android.sdk.exception.InitializeException
import cash.z.ecc.android.sdk.exception.PcztException
import cash.z.ecc.android.sdk.exception.RustLayerException
import cash.z.ecc.android.sdk.exception.TorInitializationErrorException
import cash.z.ecc.android.sdk.exception.TorUnavailableException
import cash.z.ecc.android.sdk.ext.ZcashSdk
import cash.z.ecc.android.sdk.internal.FastestServerFetcher
import cash.z.ecc.android.sdk.internal.Files
import cash.z.ecc.android.sdk.internal.SaplingParamFetcher
import cash.z.ecc.android.sdk.internal.SaplingParamTool
import cash.z.ecc.android.sdk.internal.Twig
import cash.z.ecc.android.sdk.internal.block.CompactBlockDownloader
import cash.z.ecc.android.sdk.internal.db.DatabaseCoordinator
import cash.z.ecc.android.sdk.internal.exchange.UsdExchangeRateFetcher
import cash.z.ecc.android.sdk.internal.jni.RustBackend
import cash.z.ecc.android.sdk.internal.model.LazyTorClient
import cash.z.ecc.android.sdk.internal.model.TorClient
import cash.z.ecc.android.sdk.internal.model.TreeState
import cash.z.ecc.android.sdk.internal.model.ext.toBlockHeight
import cash.z.ecc.android.sdk.internal.storage.preference.EncryptedPreferenceProvider
import cash.z.ecc.android.sdk.internal.storage.preference.StandardPreferenceProvider
import cash.z.ecc.android.sdk.internal.transaction.EndpointTransactionSubmitter
import cash.z.ecc.android.sdk.internal.transaction.PendingSubmitPlanStore
import cash.z.ecc.android.sdk.internal.transaction.SubmitPlanExecutor
import cash.z.ecc.android.sdk.model.Account
import cash.z.ecc.android.sdk.model.AccountBalance
import cash.z.ecc.android.sdk.model.AccountCreateSetup
import cash.z.ecc.android.sdk.model.AccountImportSetup
import cash.z.ecc.android.sdk.model.AccountUuid
import cash.z.ecc.android.sdk.model.BlockHeight
import cash.z.ecc.android.sdk.model.CreatedTransaction
import cash.z.ecc.android.sdk.model.FastestServersResult
import cash.z.ecc.android.sdk.model.ObserveFiatCurrencyResult
import cash.z.ecc.android.sdk.model.Pczt
import cash.z.ecc.android.sdk.model.PercentDecimal
import cash.z.ecc.android.sdk.model.Proposal
import cash.z.ecc.android.sdk.model.SdkFlags
import cash.z.ecc.android.sdk.model.SingleUseTransparentAddress
import cash.z.ecc.android.sdk.model.TransactionId
import cash.z.ecc.android.sdk.model.TransactionOutput
import cash.z.ecc.android.sdk.model.TransactionOverview
import cash.z.ecc.android.sdk.model.TransactionRecipient
import cash.z.ecc.android.sdk.model.TransactionSubmitResult
import cash.z.ecc.android.sdk.model.UnifiedAddressRequest
import cash.z.ecc.android.sdk.model.UnifiedSpendingKey
import cash.z.ecc.android.sdk.model.Zatoshi
import cash.z.ecc.android.sdk.model.ZcashNetwork
import cash.z.ecc.android.sdk.tool.CheckpointTool
import cash.z.ecc.android.sdk.type.AddressType
import cash.z.ecc.android.sdk.type.ConsensusMatchType
import cash.z.ecc.android.sdk.type.ServerValidation
import cash.z.ecc.android.sdk.util.WalletClientFactory
import co.electriccoin.lightwallet.client.CombinedWalletClient
import co.electriccoin.lightwallet.client.ServiceMode
import co.electriccoin.lightwallet.client.model.BlockHeightUnsafe
import co.electriccoin.lightwallet.client.model.LightWalletEndpoint
import co.electriccoin.lightwallet.client.model.Response
import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.HttpClientEngineConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import java.io.Closeable
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

@Suppress("TooManyFunctions")
interface Synchronizer {
    // Status

    /**
     * The network to which this synchronizer is connected and from which it is processing blocks.
     */
    val network: ZcashNetwork

    /**
     * A flow of values representing the [Status] of this Synchronizer. As the status changes, a new
     * value will be emitted by this flow.
     */
    val status: Flow<Status>

    /**
     * Indicates the download progress of the Synchronizer.
     *
     * When progress reaches `PercentDecimal.ONE_HUNDRED_PERCENT`, it signals that the Synchronizer
     * is up-to-date with the network's current chain tip. Balances should be considered inaccurate
     * and outbound transactions should be prevented until this sync is complete.
     */
    val progress: Flow<PercentDecimal>

    /**
     * Indicates whether are the shielded wallet balances spendable or not during the block synchronization process.
     */
    val areFundsSpendable: Flow<Boolean>

    /**
     * A flow of processor details, updated every time blocks are processed to include the latest
     * block height, blocks downloaded and blocks scanned. Similar to the [progress] flow but with a
     * lot more detail.
     */
    val processorInfo: Flow<CompactBlockProcessor.ProcessorInfo>

    /**
     * The latest height observed on the network, which does not necessarily correspond to the
     * latest downloaded height or scanned height. Although this is present in [processorInfo], it
     * is such a frequently used value that it is convenient to have the real-time value by itself.
     */
    val networkHeight: StateFlow<BlockHeight?>

    /**
     * The height to which the wallet has been fully scanned.
     *
     * This is the height for which the wallet has fully trial-decrypted this and all preceding
     * blocks above the wallet's birthday height. This value is useful for determining whether the
     * wallet has scanned up to a specific snapshot height.
     */
    val fullyScannedHeight: StateFlow<BlockHeight?>

    /**
     * A stream of wallet balances
     */
    val walletBalances: StateFlow<Map<AccountUuid, AccountBalance>?>

    /**
     * The latest known USD/ZEC exchange rate, paired with the time it was queried.
     *
     * The rate can be initialized and refreshed by calling [refreshExchangeRateUsd].
     */
    val exchangeRateUsd: StateFlow<ObserveFiatCurrencyResult>

    /**
     * A flow of all the transactions that are on the blockchain.
     */
    val allTransactions: Flow<List<TransactionOverview>>

    //
    // Latest Properties
    //

    /**
     * An in-memory reference to the latest height seen on the network.
     */
    val latestHeight: BlockHeight?

    /**
     * An in-memory reference to the best known birthday height, which can change if the first
     * transaction has not yet occurred.
     */
    val latestBirthdayHeight: BlockHeight?

    /**
     * Creates transactions without submitting them and submits created transactions
     * to caller-selected lightwalletd endpoints.
     *
     * The default implementation throws [UnsupportedOperationException]. SDK-backed
     * synchronizers override this with a working broadcaster.
     */
    val broadcaster: Broadcaster
        get() = UnavailableBroadcaster

    //
    // Operations
    //

    /**
     * Returns all the wallet accounts or throws [InitializeException.GetAccountsException]
     *
     * @return List of all wallet accounts
     * @throws [InitializeException.GetAccountsException] in case of the operation failure
     */
    suspend fun getAccounts(): List<Account>

    /**
     * Returns all the wallet accounts or throws [InitializeException.GetAccountsException]
     *
     * It's a Flow version of [getAccounts]
     *
     * @return Flow of all wallet accounts
     * @throws [InitializeException.GetAccountsException] in case of the operation failure
     */
    val accountsFlow: Flow<List<Account>?>

    /**
     * Emits error states of the synchronizer.
     *
     * Since Tor client creation is now lazy (see [InitializationError.TOR_NOT_AVAILABLE]), this is not
     * currently produced at construction time; Tor bootstrap failures instead surface per-call, e.g. as
     * [TorInitializationErrorException] from [getTorHttpClient] or as `Response.Failure.OverTor` from
     * Tor-mode network calls.
     */
    val initializationError: InitializationError?

    /**
     * Tells the wallet to track an account using a unified full viewing key.
     *
     * Returns details about the imported account, including the unique account identifier for
     * the newly-created wallet database entry. Unlike the other account creation APIs, no spending
     * key is returned because the wallet has no information about the mnemonic phrase from which
     * the UFVK was derived.
     *
     * @param purpose Metadata describing whether or not data required for spending should be tracked by the wallet
     * @param setup The account's setup information. See [AccountImportSetup] for more.
     *
     * @return Account containing details about the imported account, including the unique account identifier for the
     * newly-created wallet database entry
     *
     * @throws [InitializeException.ImportAccountException] in case of the operation failure
     */
    suspend fun importAccountByUfvk(setup: AccountImportSetup): Account

    /*
     * Not ready to be a public API; internal for testing only
     *
     * Adds the next available account-level spend authority, given the current set of
     * [ZIP 316](https://zips.z.cash/zip-0316) account identifiers known, to the wallet
     * database.
     *
     * The caller should store the byte encoding of the returned spending key in a secure
     * fashion. This encoding MUST NOT be exposed to users. It is an internal encoding
     * that is inherently unstable, and only intended to be passed between the SDK and the
     * storage backend. The caller MUST NOT allow this encoding to be exported or
     * imported.
     *
     * If `seed` was imported from a backup and this method is being used to restore a
     * previous wallet state, you should use this method to add all of the desired
     * accounts before scanning the chain from the seed's birthday height.
     *
     * By convention, wallets should only allow a new account to be generated after funds
     * have been received by the currently-available account (in order to enable
     * automated account recovery).
     *
     * @param recoverUntil An optional height at which the wallet should exit "recovery mode"
     * @param setup The wallet's setup information. See [AccountCreateSetup] for more.
     * @param treeState The tree state corresponding to the last block prior to the wallet's birthday height
     *
     * @return the newly created ZIP 316 account identifier, along with the binary
     * encoding of the `UnifiedSpendingKey` for the newly created account.
     *
     * @throws [InitializeException.CreateAccountException] in case of the operation failure
     *
    suspend fun createAccount(
        setup: AccountCreateSetup,
        treeState: TreeState,
        recoverUntil: BlockHeight?
    ): UnifiedSpendingKey
     */

    /**
     * Measure connection quality and speed of given [servers].
     *
     * @return a [Flow] of fastest servers which updates it's state during measurement stages
     */
    suspend fun getFastestServers(servers: List<LightWalletEndpoint>): Flow<FastestServersResult>

    /**
     * This function decides whether automatic server selection should move the wallet away from [current].
     *
     * [current] and every endpoint in [candidates] are benchmarked in full: server info and latest block
     * height are fetched and timed, and an endpoint is ruled out unless its chain name, consensus branch
     * and sync state match this SDK. Each survivor then streams the same [blocksToFetch] blocks, ending at
     * the lowest tip any survivor reported; the stream time is its score and a candidate that needs longer
     * than [fetchThreshold] is ruled out. [current] is measured whether or not [candidates] contains it,
     * so a host dropped from the caller's list is never abandoned without being measured.
     *
     * A switch is only recommended when the best candidate beats [current] by at least 200 milliseconds and
     * by at least 25 percent of the current server's score, or when [current] fails benchmarking in two
     * consecutive evaluations. A switch of the first kind is additionally held off for thirty minutes after
     * the previous one; a switch away from a server that could not be measured is not, because the two
     * consecutive failures are already its gate and waiting out the cooldown on an unreachable server costs
     * more than the rebuild does. This hysteresis keeps the wallet from flip-flopping between two
     * near-equal or intermittently slow servers; the consecutive-failure count and the cooldown are held in
     * memory for the lifetime of the process. The failure count belongs to the server it was accrued
     * against, so changing [current] between evaluations starts it over.
     *
     * This call only counts a failed measurement of [current]; it never clears that count and never starts
     * the cooldown, because the caller is free to decline the recommendation. Call [confirmServerSwitch]
     * once the returned endpoint has actually been applied - without it the cooldown never starts, and with
     * it on a switch that never happened a genuinely broken server would be given another thirty minutes.
     *
     * @param current the endpoint the wallet is connected to right now
     * @param candidates the endpoints to benchmark alongside [current]
     * @param fetchThreshold per-candidate cap for the block-fetch stage
     * @param blocksToFetch how many blocks to stream from every candidate while timing it
     *
     * @return the endpoint to switch to, or null when the wallet should stay on [current]
     */
    suspend fun evaluateServerSwitch(
        current: LightWalletEndpoint,
        candidates: List<LightWalletEndpoint>,
        fetchThreshold: Duration = 5.seconds,
        blocksToFetch: Int = 1
    ): LightWalletEndpoint?

    /**
     * Tells the SDK that the wallet has actually been moved to [endpoint], which [evaluateServerSwitch]
     * recommended. The consecutive-failure count starts over against [endpoint] and the switch cooldown
     * starts now.
     *
     * Call this only after the switch was applied, and always when it was; see [evaluateServerSwitch].
     *
     * @param endpoint the endpoint the wallet was moved to
     */
    suspend fun confirmServerSwitch(endpoint: LightWalletEndpoint)

    /**
     * Gets the current unified address for the given account.
     *
     * @param account the account whose address is of interest.
     *
     * @return the current unified address for the given account.
     *
     * @throws RustLayerException.GetAddressException in case of the operation
     */
    @Throws(RustLayerException.GetAddressException::class)
    suspend fun getUnifiedAddress(account: Account): String

    /**
     * Gets a new unified address that conforms to the specified request.
     *
     * @param account the account whose address is of interest.
     * @param request a description of the receivers to create in the newly generated address.
     *
     * @return the current unified address for the given account.
     *
     * @throws RustLayerException.GetAddressException if the account cannot create an address with the requested
     * receivers.
     */
    @Throws(RustLayerException.GetAddressException::class)
    suspend fun getCustomUnifiedAddress(account: Account, request: UnifiedAddressRequest): String

    /**
     * Gets the legacy Sapling address corresponding to the current unified address for the given account.
     *
     * @param account the account whose address is of interest.
     *
     * @return a legacy Sapling address for the given account.
     *
     * @throws RustLayerException.GetAddressException in case of the operation
     */
    @Throws(RustLayerException.GetAddressException::class)
    suspend fun getSaplingAddress(account: Account): String

    /**
     * Gets the legacy transparent address corresponding to the current unified address for the given account.
     *
     * @param account the account whose address is of interest.
     *
     * @return a legacy transparent address for the given account.
     *
     * @throws RustLayerException.GetAddressException in case of the operation
     */
    @Throws(RustLayerException.GetAddressException::class)
    suspend fun getTransparentAddress(account: Account): String

    /**
     * Refreshes [exchangeRateUsd].
     */
    fun refreshExchangeRateUsd()

    /**
     * Creates a proposal for transferring funds to the given recipient.
     *
     * @param account the account from which to transfer funds.
     * @param recipient the recipient's address.
     * @param amount the amount of zatoshi to send.
     * @param memo the optional memo to include as part of the proposal's transactions.
     *
     * @return the proposal or an exception
     *
     * @throws TransactionEncoderException.InsufficientFundsException if the account cannot cover the
     * requested amount together with the required fee
     * @throws TransactionEncoderException.ProposalFromParametersException if the proposal cannot be
     * created for any other reason
     */
    suspend fun proposeTransfer(
        account: Account,
        recipient: String,
        amount: Zatoshi,
        memo: String = ""
    ): Proposal

    /**
     * Creates a proposal migrating the account's entire Orchard balance into the Ironwood
     * pool, introduced by NU6.3.
     *
     * The proposal spends every Orchard note the account holds and sends the maximum to the
     * account's own internal receiver, with the fee computed so that no change is left in
     * Orchard. Sapling and transparent funds are not touched.
     *
     * This is deliberately all-or-nothing: if any Orchard note is not yet spendable the
     * proposal fails rather than migrating part of the balance and reporting success. After
     * NU6.3 the Orchard turnstile forbids adding value back to the Orchard pool, so funds
     * left behind would be stranded in a pool the wallet is leaving.
     *
     * Note this reveals the account's Orchard balance on-chain: the migration is a single
     * transaction of exactly that value. It does not attempt to split the crossing into
     * less-identifying amounts.
     *
     * @param account the account whose Orchard funds to migrate.
     *
     * @return the proposal or an exception
     *
     * @throws TransactionEncoderException.InsufficientFundsException if the account cannot cover the
     * migration together with the required fee
     * @throws TransactionEncoderException.ProposalFromParametersException if NU6.3 is not
     * active, if any Orchard note is not yet spendable, or if the proposal cannot be created
     */
    suspend fun proposeOrchardToIronwoodMigration(account: Account): Proposal

    /**
     * Creates a proposal for fulfilling a payment ZIP-321 URI
     *
     * @param account the account from which to transfer funds.
     * @param uri a ZIP-321 compliant payment URI String
     *
     * @return the proposal or an exception
     *
     * @throws TransactionEncoderException.InsufficientFundsException if the account cannot cover the
     * requested payment together with the required fee
     * @throws TransactionEncoderException.ProposalFromUriException if the proposal cannot be created
     * for any other reason
     */
    suspend fun proposeFulfillingPaymentUri(
        account: Account,
        uri: String
    ): Proposal

    /**
     * Creates a proposal for shielding any transparent funds received by the given account.
     *
     * @param account the account for which to shield funds.
     * @param shieldingThreshold the minimum transparent balance required before a
     *                           proposal will be created.
     * @param memo the optional memo to include as part of the proposal's transactions.
     * @param transparentReceiver a specific transparent receiver within the account that
     *                            should be the source of transparent funds. Default is
     *                            null which will select whichever of the account's
     *                            transparent receivers has funds to shield.
     *
     * @return the proposal, or null if the transparent balance that would be shielded is
     *         zero or below `shieldingThreshold`.
     *
     * @throws TransactionEncoderException.InsufficientFundsException if the transparent funds do not
     *         cover the required fee
     * @throws TransactionEncoderException.ProposalShieldingException if the proposal cannot be
     *         created for any other reason, e.g. if `transparentReceiver` is null and there are
     *         transparent funds in more than one of the account's transparent receivers.
     */
    suspend fun proposeShielding(
        account: Account,
        shieldingThreshold: Zatoshi,
        memo: String = ZcashSdk.DEFAULT_SHIELD_FUNDS_MEMO_PREFIX,
        transparentReceiver: String? = null
    ): Proposal?

    /**
     * Creates the transactions in the given proposal.
     *
     * @param proposal the proposal for which to create transactions.
     * @param usk the unified spending key associated with the account for which the
     *            proposal was created.
     *
     * @return a flow of result objects for the transactions that were created as part of
     *         the proposal, indicating whether they were submitted to the network or if
     *         an error occurred.
     */
    suspend fun createProposedTransactions(
        proposal: Proposal,
        usk: UnifiedSpendingKey
    ): Flow<TransactionSubmitResult>

    /**
     * Creates a partially-created (unsigned without proofs) transaction from the given proposal.
     *
     * Do not call this multiple times in parallel, or you will generate PCZT instances that, if
     * finalized, would double-spend the same notes.
     *
     * @param accountUuid The account for which the proposal was created.
     * @param proposal The proposal for which to create the transaction.
     *
     * @return The partially created transaction in [Pczt] format.
     *
     * @throws PcztException.MultiStepProposalUnsupportedException if the proposal needs more than one
     * transaction, which an external PCZT signer cannot fulfill
     * @throws PcztException.CreatePcztFromProposalException as a common indicator of the operation failure
     */
    @Throws(
        PcztException.MultiStepProposalUnsupportedException::class,
        PcztException.CreatePcztFromProposalException::class
    )
    suspend fun createPcztFromProposal(
        accountUuid: AccountUuid,
        proposal: Proposal
    ): Pczt

    /**
     * Redacts information from the given PCZT that is unnecessary for the Signer role.
     *
     * @param pczt The partially created transaction in its serialized format.
     *
     * @return the updated PCZT in its serialized format.
     *
     * @throws PcztException.RedactPcztForSignerException as a common indicator of the operation failure
     */
    @Throws(PcztException.RedactPcztForSignerException::class)
    suspend fun redactPcztForSigner(pczt: Pczt): Pczt

    /**
     * Checks whether the caller needs to have downloaded the Sapling parameters.
     *
     * @param pczt The partially created transaction in its serialized format.
     *
     * @return `true` if this PCZT requires Sapling proofs.
     *
     * @throws PcztException.PcztRequiresSaplingProofsException as a common indicator of the operation failure
     */
    @Throws(PcztException.PcztRequiresSaplingProofsException::class)
    suspend fun pcztRequiresSaplingProofs(pczt: Pczt): Boolean

    /**
     * Adds proofs to the given PCZT.
     *
     * @param pczt The partially created transaction in its serialized format.
     *
     * @return The updated PCZT in its serialized format.
     *
     * @throws PcztException.AddProofsToPcztException as a common indicator of the operation failure
     */
    @Throws(PcztException.AddProofsToPcztException::class)
    suspend fun addProofsToPczt(pczt: Pczt): Pczt

    /**
     * Takes a PCZT that has been separately proven and signed, finalizes it, and stores
     * it in the wallet. Internally, this logic also submits and checks the newly stored and encoded transaction.
     *
     * @param pcztWithProofs
     * @param pcztWithSignatures
     *
     * @return The submission result of the completed transaction.
     *
     * @throws PcztException.ExtractAndStoreTxFromPcztException as a common indicator of the operation failure
     */
    @Throws(PcztException.ExtractAndStoreTxFromPcztException::class)
    suspend fun createTransactionFromPczt(
        pcztWithProofs: Pczt,
        pcztWithSignatures: Pczt,
    ): Flow<TransactionSubmitResult>

    // TODO [#1534]: Add RustLayerException.ValidateAddressException
    // TODO [#1534]: https://github.com/Electric-Coin-Company/zcash-android-wallet-sdk/issues/1534

    /**
     * Returns true when the given address is a valid z-addr. Invalid addresses will throw an
     * exception. See valid z-addresses characteristics in related ZIP.
     *
     * @param address the address to validate.
     *
     * @return true when the given address is a valid z-addr.
     *
     * @throws RuntimeException when the address is invalid.
     */
    suspend fun isValidShieldedAddr(address: String): Boolean

    /**
     * Returns true when the given address is a valid t-addr. Invalid addresses will throw an
     * exception. See valid t-addresses characteristics in related ZIP.
     *
     * @param address the address to validate.
     *
     * @return true when the given address is a valid t-addr.
     *
     * @throws RuntimeException when the address is invalid.
     */
    suspend fun isValidTransparentAddr(address: String): Boolean

    /**
     * Returns true when the given address is a valid ZIP 316 unified address.
     *
     * This method is intended for type checking (e.g. form validation). Invalid
     * addresses will throw an exception.
     *
     * @param address the address to validate.
     *
     * @return true when the given address is a valid unified address.
     *
     * @throws RuntimeException when the address is invalid.
     */
    suspend fun isValidUnifiedAddr(address: String): Boolean

    /**
     * Returns true when the given address is a valid ZIP 320 TEX address.
     *
     * This method is intended for type checking (e.g. form validation). Invalid
     * addresses will throw an exception. See valid t-addresses characteristics
     * in the related ZIP.
     *
     * @param address the address to validate.
     *
     * @return true when the given address is a valid ZIP 320 TEX address.
     *
     * @throws RuntimeException when the address is invalid.
     */
    suspend fun isValidTexAddr(address: String): Boolean

    /**
     * Validate whether the server and this SDK share the same consensus branch. This is
     * particularly important to check around network updates so that any wallet that's connected to
     * an incompatible server can surface that information effectively. For the SDK, the consensus
     * branch is used when creating transactions as each one needs to target a specific branch. This
     * function compares the server's branch id to this SDK's and returns information that helps
     * determine whether they match.
     *
     * @return an instance of [ConsensusMatchType] that is essentially a wrapper for both branch ids
     * and provides helper functions for communicating detailed errors to the user.
     */
    suspend fun validateConsensusBranch(): ConsensusMatchType

    /**
     * This function checks whether the provided server endpoint is valid. The validation is based on comparing:
     * - network types,
     * - sapling activation heights
     * - consensus branches
     *
     * @param endpoint LightWalletEndpoint data to be validated
     * @param context Context
     *
     * @return an instance of [ServerValidation] that provides details about the validation result
     */
    suspend fun validateServerEndpoint(
        context: Context,
        endpoint: LightWalletEndpoint
    ): ServerValidation

    /**
     * Validates the given address, returning information about why it is invalid. This is a
     * convenience method that combines the behavior of [isValidShieldedAddr],
     * [isValidTransparentAddr], and [isValidUnifiedAddr] into one call so that the developer
     * doesn't have to worry about handling the exceptions that they throw. Rather, exceptions
     * are converted to [AddressType.Invalid] which has a `reason` property describing why it is
     * invalid.
     *
     * @param address the address to validate.
     *
     * @return an instance of [AddressType] providing validation info regarding the given address.
     */
    suspend fun validateAddress(address: String): AddressType

    /**
     * Download all UTXOs for the given account addresses and store any new ones in the database.
     *
     * @param account The Account, for which all addresses blocks will be downloaded.
     * @param since The BlockHeight, from which blocks will be downloaded.
     *
     * @return the number of utxos that were downloaded and added to the UTXO table.
     */
    suspend fun refreshUtxos(
        account: Account,
        since: BlockHeight = network.saplingActivationHeight
    ): Int?

    /**
     * Returns the balance that the wallet knows about. This should be called after [refreshUtxos].
     */
    suspend fun getTransparentBalance(tAddr: String): Zatoshi

    /**
     * Rewinds to the safest height to which we can rewind, given a desire to rewind to the height
     * provided.
     *
     * Due to how witness incrementing works, a wallet cannot simply rewind to any
     * arbitrary height. This handles all that complexity yet remains flexible in the future as
     * improvements are made.
     *
     * Returns the height to which we actually rewound, or `null` if the rewind failed.
     */
    suspend fun rewindToNearestHeight(height: BlockHeight): BlockHeight?

    /**
     * Truncates the data database to the specified chain state.
     *
     * In contrast to [rewindToNearestHeight], this method allows the caller to truncate the wallet
     * database to a precise height. The SDK internally loads the checkpoint for the given height
     * and extracts the TreeState needed for the rewind operation.
     *
     * @param height The target block height to rewind to.
     */
    suspend fun rewindToHeight(height: BlockHeight)

    /**
     * Returns a stream of memos for a transaction. It works for both received and sent transaction.
     *
     * Note that this function internally resolves any error which comes, logs it, and then transforms it to an empty
     * string.
     *
     * @param transactionOverview For which the memos will be queried
     * @return Flow of memo strings
     */
    fun getMemos(transactionOverview: TransactionOverview): Flow<String>

    /**
     * Filters the current transactions based on their memos. It returns the transaction ID of those transactions
     * whose memo contains the given [query] or its part. Note that white space trimming or normalization is the
     * client's responsibility.
     *
     * @param query Memo or its substring
     * @return List of transaction IDs which memo contains given [query] or its part wrapped in [Flow]
     */
    fun getTransactionsByMemoSubstring(query: String): Flow<List<TransactionId>>

    /**
     * Returns a list of recipients for a transaction. May include wallet-internal entries (the recipient's
     * [TransactionRecipient.accountUuid] is non-null) whose [TransactionRecipient.addressValue] is the stored
     * receiving address where the wallet recorded one (else null), so a self-transfer (e.g. a pool migration)
     * surfaces a recipient instead of being filtered out as change.
     */
    fun getRecipients(transactionOverview: TransactionOverview): Flow<TransactionRecipient>

    /**
     * Batched alternative to [getRecipients] that returns the recipients for ALL transactions in a single query,
     * grouped by [TransactionId]. Prefer this over calling [getRecipients] in a loop for every transaction, e.g.
     * when building a transaction list for the UI.
     *
     * The map only contains entries for transactions that have at least one recipient; a transaction with only
     * change outputs (or no outputs) is absent from the map rather than being present with an empty list.
     */
    suspend fun getRecipients(): Map<TransactionId, List<TransactionRecipient>>

    /**
     * Checks and provides file path to the existing data database file for the given input parameters or throws
     * [InitializeException.MissingDatabaseException] if the database does not exist yet.
     *
     * Note that it's the caller's responsibility to provide a [network] and [alias] to an existing database. Otherwise
     * [InitializeException.MissingDatabaseException] is thrown.
     *
     * @return Path to the already created data database file, or null in case none exists yet
     * @throws [InitializeException.MissingDatabaseException] When the requested database for the given inputs
     * does not exist yet.
     */
    @Throws(InitializeException.MissingDatabaseException::class)
    suspend fun getExistingDataDbFilePath(
        context: Context,
        network: ZcashNetwork,
        alias: String = ZcashSdk.DEFAULT_ALIAS
    ): String

    /**
     * Returns a list of all transaction outputs for a transaction.
     */
    suspend fun getTransactionOutputs(transactionOverview: TransactionOverview): List<TransactionOutput>

    /**
     * Batched alternative to [getTransactionOutputs] that returns the transaction outputs for ALL transactions
     * in a single query, grouped by [TransactionId]. Prefer this over calling [getTransactionOutputs] in a loop
     * for every transaction, e.g. when building a transaction list for the UI.
     *
     * The map only contains entries for transactions that have at least one non-change output; a transaction
     * with only change outputs (or no outputs) is absent from the map rather than being present with an empty
     * list.
     */
    suspend fun getTransactionOutputs(): Map<TransactionId, List<TransactionOutput>>

    /**
     * Returns all transactions belonging to the given account UUID
     *
     * @param accountUuid The given account UUID
     * @return Flow of transactions by the given account UUID
     */
    suspend fun getTransactions(accountUuid: AccountUuid): Flow<List<TransactionOverview>>

    /**
     * Generates and returns an ephemeral address for one-time use, such as when receiving a swap
     * from a decentralized exchange.
     */
    suspend fun getSingleUseTransparentAddress(accountUuid: AccountUuid): SingleUseTransparentAddress

    /**
     * Checks to find any single-use ephemeral addresses exposed in the past day that have not yet
     * received funds, excluding any whose next check time is in the future. This will then choose the
     * address that is most overdue for checking, retrieve any UTXOs for that address over Tor, and
     * add them to the wallet database. If no such UTXOs are found, the check will be rescheduled
     * following an expoential-backoff-with-jitter algorithm.
     */
    suspend fun checkSingleUseTransparentAddress(accountUuid: AccountUuid): Boolean

    /**
     * Queries the light wallet server to find any UTXOs associated with the given transparent
     * address, and adds any UTXOs discovered to the wallet.
     *
     * This check will cover the block range starting at the exposure height for that address, if
     * known, or otherwise at the birthday height of the specified account.
     */
    suspend fun fetchUtxosByAddress(accountUuid: AccountUuid, address: String): Boolean

    /**
     * Requests to enhance transaction enhancement for the [txId].
     */
    fun enhanceTransaction(txId: TransactionId)

    fun onBackground()

    fun onForeground()

    /** Outcome of a bounded background sync advance — see [syncBurst]. */
    enum class SyncBurstResult {
        /** [syncBurst]'s `isTargetReached` returned true — the caller's goal was met. */
        TARGET_REACHED,

        /** The engine reached the network tip (a fresh pass refreshed the tip) without the target being met. */
        SYNCED_TO_TIP,

        /** The engine entered its error state (no server reachable, etc.). */
        DISCONNECTED,

        /** A privacy sync-block ([CloseableSynchronizer.pause]) was active — the burst refused to run. */
        PRIVACY_BLOCKED,

        /** [syncBurst]'s `timeout` elapsed before any other terminal. */
        TIMEOUT,

        /** This [Synchronizer] implementation cannot drive a bounded burst (or is closed). */
        UNAVAILABLE,
    }

    /**
     * Actively drives a bounded sync pass even while the app is backgrounded (i.e. after
     * [onBackground] stopped the engine), then restores the prior lifecycle state. Unlike merely
     * observing [status] — which a stopped or paused engine reports as [Status.SYNCED] against a
     * stale chain tip — this force-starts the engine so the synced tip actually advances, which is
     * what the migration background worker needs to make a scheduled transfer become broadcastable.
     *
     * Never overrides a privacy pause: while paused ([CloseableSynchronizer.pause]) it returns
     * [SyncBurstResult.PRIVACY_BLOCKED] without touching the network, so the burst and a later
     * migration broadcast stay decoupled in time. [isTargetReached] is polled roughly every
     * [targetCheckInterval] and must be cheap and idempotent — e.g. the migration engine's
     * height-gated `hasOverdueTransfers()`.
     *
     * The default implementation is a no-op returning [SyncBurstResult.UNAVAILABLE]; only the
     * Slipstream engine drives a real burst.
     */
    suspend fun syncBurst(
        timeout: Duration,
        targetCheckInterval: Duration = 5.seconds,
        isTargetReached: suspend () -> Boolean,
    ): SyncBurstResult = SyncBurstResult.UNAVAILABLE

    /**
     * Drives a bounded sync pass until the engine reaches the current network tip (i.e.
     * [SyncBurstResult.SYNCED_TO_TIP]), then returns. Unlike [syncBurst] with a caller-supplied
     * target, this never returns [SyncBurstResult.TARGET_REACHED] — callers that only need to
     * be sure the wallet is up to date (Lane A in the migration two-lane model) use this instead
     * of supplying their own [isTargetReached] predicate.
     *
     * Delegates to [syncBurst] with `isTargetReached = { false }`, so all of [syncBurst]'s
     * guarantees apply: privacy pauses are respected, the timeout bounds the call, and a
     * [SyncBurstResult.UNAVAILABLE] is returned by implementations that cannot drive a real burst.
     */
    suspend fun syncToTip(timeout: Duration): SyncBurstResult =
        syncBurst(timeout = timeout, isTargetReached = { false })

    /**
     * Restarts the underlying sync-engine session so session-scoped configuration is recomputed.
     *
     * The migration anchor-retention floor (the lowest boundary height whose commitment-tree
     * checkpoints must be created and retained on the anchor grid) is read ONCE, when a sync
     * session starts. A session that was already live when a migration plan committed therefore
     * runs WITHOUT retention for that plan's boundaries — and the first boundary it scans past
     * loses its checkpoint permanently (checkpoints cannot be created retroactively), making the
     * transfer anchored to it unprovable forever. Callers that commit a migration plan MUST call
     * this immediately afterwards, before the chain crosses the plan's first boundary.
     *
     * Returns `false` when the implementation has no restartable session (or is closed); the
     * default implementation is a no-op returning `false`.
     */
    suspend fun restartSyncSession(): Boolean = false

    /**
     *
     * @param config to configure [HttpClient]
     *
     * @return http client that does http communication over Tor network
     *
     * @throws TorInitializationErrorException if an error occurred during Tor setup
     * @throws TorUnavailableException if Tor or exchange rate is not enabled
     */
    @Throws(TorInitializationErrorException::class, TorUnavailableException::class)
    suspend fun getTorHttpClient(config: HttpClientConfig<HttpClientEngineConfig>.() -> Unit = {}): HttpClient

    suspend fun debugQuery(query: String): String

    suspend fun deleteAccount(accountUuid: AccountUuid): Boolean

    /**
     * Returns the commitment tree state at the given block height, encoded as a protobuf [ByteArray].
     *
     * This lets app-layer consumers generate witnesses or verify inclusion proofs against a
     * specific Orchard note commitment tree snapshot without exposing the lightwalletd transport.
     *
     * This performs a live lightwalletd request and does not wait for the local wallet scan state.
     * Callers that use the returned tree state together with local wallet data at the same height
     * should first verify that [fullyScannedHeight] has reached at least [height].
     */
    suspend fun getTreeState(height: BlockHeight): ByteArray

    suspend fun getWalletDbPathForVoting(): String

    //
    // Error Handling
    //

    /**
     * Gets or sets a global error handler. This is a useful hook for handling unexpected critical
     * errors.
     *
     * @return true when the error has been handled and the Synchronizer should attempt to continue.
     * False when the error is unrecoverable and the Synchronizer should [stop].
     */
    var onCriticalErrorHandler: ((Throwable?) -> Boolean)?

    /**
     * An error handler for exceptions during processing. For instance, a block might be missing or
     * a reorg may get mishandled or the database may get corrupted.
     *
     * @return true when the error has been handled and the processor should attempt to continue.
     * False when the error is unrecoverable and the processor should [stop].
     */
    var onProcessorErrorHandler: ((Throwable?) -> Boolean)?

    var onProcessorErrorResolved: (() -> Unit)?

    /**
     * Callback for setup errors that occur prior to processing compact blocks. Can be used to
     * override any errors encountered during setup. When this listener is missing then all setup
     * errors will result in the synchronizer not starting. This is particularly useful for wallets
     * to receive a callback right before the SDK will reject a lightwalletd server because it
     * appears not to match.
     *
     * @return true when the setup error should be ignored and processing should be allowed to
     * start. Otherwise, processing will not begin.
     */
    var onSetupErrorHandler: ((Throwable?) -> Boolean)?

    /**
     * The state-flow twin of [onSetupErrorHandler]'s latched failure, for consumers that want to
     * observe it rather than own the single [onSetupErrorHandler] slot. [onSetupErrorHandler] is a
     * `var`: whichever caller assigns it last silently replaces any handler a different caller
     * already installed, which is a real hazard when both an SDK-internal coordinator and a host
     * app each want to react to the same failure. A [StateFlow] has no such single-slot problem -
     * any number of independent collectors can observe the same latched value.
     *
     * Always emits `null` on an engine whose setup failures are thrown synchronously out of
     * [Synchronizer.new] instead of latched (the default engine). An engine that instead defers
     * setup failures past construction - surfacing them only through [onSetupErrorHandler] - is
     * expected to latch the same failure here too.
     */
    val setupError: StateFlow<Throwable?>

    /**
     * A callback to invoke whenever a chain error is encountered. These occur whenever the
     * processor detects a missing or non-chain-sequential block (i.e. a reorg). At a minimum, it is
     * best to log these errors because they are the most common source of bugs and unexpected
     * behavior in wallets, due to the chain data mutating and wallets becoming out of sync.
     */
    var onChainErrorHandler: ((BlockHeight, BlockHeight) -> Any)?

    /**
     * Represents the status of this Synchronizer, which is useful for communicating to the user.
     */
    enum class Status {
        /**
         * Indicates the initial state of Synchronizer
         */
        INITIALIZING,

        /**
         * Indicates that [stop] has been called on this Synchronizer and it will no longer be used.
         */
        STOPPED,

        /**
         * Indicates that this Synchronizer is disconnected from its lightwalletd server.
         * When set, a UI element may want to turn red.
         */
        DISCONNECTED,

        /**
         * Indicates that the Synchronizer is actively syncing new blocks. It goes through these stages internally:
         * downloading new blocks, validating these blocks, then scanning them, deleting the temporary persisted block
         * files, and enhancing transaction details at the end.
         *
         * In the downloading stage, the Synchronizer is actively downloading new blocks from the
         * server.
         *
         * In the validating stage, the Synchronizer is actively validating new blocks that were downloaded
         * from the server. Blocks need to be verified before they are scanned. This confirms that
         * each block is chain-sequential, thereby detecting missing blocks and reorgs.
         *
         * In the scanning stage, Synchronizer is actively decrypting new blocks that were downloaded
         * from the server.
         *
         * In the deleting stage are all temporary persisted block files removed from the persistence.
         *
         * In the enhancing stage is the Synchronizer actively enhancing newly scanned blocks with additional
         * transaction details, fetched from the server.
         */
        SYNCING,

        /**
         * Indicates that this Synchronizer is fully up to date and ready for all wallet functions.
         * When set, a UI element may want to turn green. In this state, the balance can be trusted.
         */
        SYNCED
    }

    enum class InitializationError {
        /**
         * Indicates that tor is required but not available.
         *
         * Typically this means that [SdkFlags.isTorEnabled] is set to true but Tor instantiation
         * failed.
         *
         * Tor client creation is lazy (deferred to first use, via `LazyTorClient`) rather than happening
         * eagerly during [Synchronizer.Companion.new], so this error is no longer produced at
         * construction time. Tor bootstrap failures now surface per-call instead, e.g. as
         * [TorInitializationErrorException] from [getTorHttpClient] or as `Response.Failure.OverTor` from
         * Tor-mode network calls. This case is kept for source/binary compatibility.
         */
        TOR_NOT_AVAILABLE,
    }

    companion object {
        /**
         * Eagerly loads the native Rust library used by the SDK.
         *
         * Loading the native library ([System.loadLibrary]) is a one-time, process-wide cost that
         * otherwise happens on the cold-start critical path inside [new] (as part of building the
         * backend). Clients can call this early — e.g. from `Application.onCreate` or during a splash/
         * authentication screen — so the cost overlaps that idle time and [new] returns faster.
         *
         * This is idempotent and safe to call multiple times and concurrently with [new]; the load
         * happens at most once.
         */
        suspend fun preloadNativeLibrary() {
            RustBackend.loadLibrary()
        }

        /**
         * Primary method that SDK clients will use to construct a synchronizer.
         *
         * The construction of a [Synchronizer] is split into independent branches that run concurrently
         * on background threads, then joined. The critical path to an emitting DB (backend native-load →
         * repository/initDataDb) no longer serializes behind the network client (gRPC walletClient),
         * checkpoint load, or preference disk I/O — all of which are only needed for syncing, not for
         * reading stored balances/transactions.
         *
         * @param zcashNetwork the network to use.
         *
         * @param alias A string used to segregate multiple wallets in the filesystem.  This implies the string
         * should not contain characters unsuitable for the platform's filesystem.  The default value is
         * generally used unless an SDK client needs to support multiple wallets.
         *
         * @param lightWalletEndpoint Server endpoint.  See [cash.z.ecc.android.sdk.model.defaultForNetwork]. If a
         * client wishes to change the server endpoint, the active synchronizer will need to be stopped and a new
         * instance created with a new value.
         *
         * @param birthday Block height representing the "birthday" of the wallet.  When creating a new wallet, see
         * [BlockHeight.ofLatestCheckpoint].  When restoring an existing wallet, use block height that was first used
         * to create the wallet.  If that value is unknown, null is acceptable but will result in longer
         * sync times.  After sync completes, the birthday can be determined from [Synchronizer.latestBirthdayHeight].
         *
         * @param setup An optional Account setup data that holds seed and other account related information.
         * See [AccountCreateSetup] for more.
         *
         * @param walletInitMode a required parameter with one of [WalletInitMode] values. Use
         * [WalletInitMode.NewWallet] when starting synchronizer for a newly created wallet. Or use
         * [WalletInitMode.RestoreWallet] when restoring an existing wallet that was created at some point in the
         * past. Or use the last [WalletInitMode.ExistingWallet] type for a wallet which is already initialized
         * and needs follow-up block synchronization.
         *
         * @throws InitializerException.SeedRequired Indicates clients need to call this method again, providing the
         * seed bytes.
         *
         * @throws IllegalStateException If multiple instances of synchronizer with the same network+alias are
         * active at the same time.  Call `close` to finish one synchronizer before starting another one with the same
         * network+alias.
         *
         * If customized initialization is required (e.g. for dependency injection or testing), see
         * [DefaultSynchronizerFactory].
         */
        @Suppress("LongParameterList", "LongMethod", "TooGenericExceptionCaught")
        suspend fun new(
            alias: String = ZcashSdk.DEFAULT_ALIAS,
            birthday: BlockHeight?,
            context: Context,
            lightWalletEndpoint: LightWalletEndpoint,
            setup: AccountCreateSetup?,
            walletInitMode: WalletInitMode,
            zcashNetwork: ZcashNetwork,
            isTorEnabled: Boolean,
            isExchangeRateEnabled: Boolean
        ): CloseableSynchronizer {
            val applicationContext = context.applicationContext
            // Populates Twig's process/tag columns — without this every SDK log line renders a
            // 27-space empty process field (nothing else ever calls initialize).
            Twig.initialize(applicationContext)

            val sdkFlags =
                SdkFlags(
                    isTorEnabled = isTorEnabled,
                    isExchangeRateEnabled = isExchangeRateEnabled
                )

            validateAlias(alias)

            return coroutineScope {
                /**
                 * Bundled checkpoint load (asset read) — independent of everything else.
                 */
                val checkpointDeferred =
                    async(Dispatchers.Default) {
                        CheckpointTool.loadNearest(
                            context = applicationContext,
                            network = zcashNetwork,
                            birthdayHeight = birthday ?: zcashNetwork.saplingActivationHeight
                        )
                    }

                val coordinator = DatabaseCoordinator.getInstance(context)
                coordinator.deletePendingTransactionDatabase(zcashNetwork, alias)

                /**
                 * Native library load (~one-time per process) + Rust backend construction. This is the
                 * long pole of the DB-read critical path; everything Rust/DB-related awaits it.
                 */
                val backendDeferred =
                    async(Dispatchers.Default) {
                        val saplingParamTool = SaplingParamTool.new(applicationContext)
                        val backend =
                            DefaultSynchronizerFactory.defaultBackend(
                                zcashNetwork,
                                alias,
                                saplingParamTool,
                                coordinator
                            )
                        saplingParamTool to backend
                    }

                /**
                 * Tor is only needed for on-demand/background work (sync-path Tor-mode RPCs, exchange rate
                 * fetch, getTorHttpClient), never on the cold-start critical path, so its creation (the ~1s
                 * Tor runtime creation cost) is always deferred to first use via [LazyTorClient], regardless of
                 * whether isTorEnabled and/or isExchangeRateEnabled is set. Because the factory only awaits
                 * the backend when Tor is actually first used (much later), the walletClient below can be
                 * built concurrently with the backend rather than waiting for it.
                 */
                val lazyTorClient =
                    if (sdkFlags.isTorEnabled || sdkFlags.isExchangeRateEnabled) {
                        LazyTorClient {
                            val torDir = Files.getTorDir(applicationContext)
                            TorClient.new(torDir, backendDeferred.await().second.backend)
                        }
                    } else {
                        null
                    }

                val fetchExchangeChangeUsd =
                    if (sdkFlags.isExchangeRateEnabled) {
                        lazyTorClient?.let { holder ->
                            UsdExchangeRateFetcher(
                                isolatedTorClient = LazyTorClient { holder.getOrCreate().isolatedTorClient() }
                            )
                        }
                    } else {
                        null
                    }

                val walletClientFactory =
                    WalletClientFactory(
                        context = applicationContext,
                        torClient = lazyTorClient?.takeIf { sdkFlags.isTorEnabled }
                    )

                /**
                 * gRPC lightwalletd client (does not touch the Rust backend) — built concurrently.
                 */
                val walletClientDeferred =
                    async(Dispatchers.Default) {
                        walletClientFactory.create(endpoint = lightWalletEndpoint)
                    }

                /**
                 * Preference stores (disk I/O) — independent of backend and network.
                 */
                val prefsDeferred =
                    async(Dispatchers.Default) {
                        val preferenceProvider = StandardPreferenceProvider(context)()
                        val encryptedPreferenceProvider = EncryptedPreferenceProvider(applicationContext)
                        val pendingSubmitPlanStore =
                            PendingSubmitPlanStore(
                                preferenceProvider = encryptedPreferenceProvider(),
                                namespace = "${zcashNetwork.id}_$alias"
                            )
                        preferenceProvider to pendingSubmitPlanStore
                    }

                /**
                 * [walletClient] is hoisted so the `catch` blocks below can dispose it (and
                 * [lazyTorClient]) on any failure from here on, since ownership only transfers to
                 * the returned [SdkSynchronizer] once construction succeeds - on any earlier
                 * failure there would be nobody left to dispose them via `close()`. One narrow
                 * edge case is accepted as-is: if [walletClientDeferred] completes concurrently
                 * but a failure elsewhere means this function never reaches its `await()` below,
                 * that already-built client is never observed here and leaks undisposed.
                 */
                var walletClient: CombinedWalletClient? = null
                try {
                    val (saplingParamTool, backend) = backendDeferred.await()
                    val saplingParamFetcher = SaplingParamFetcher(saplingParamTool, backend)
                    val blockStore =
                        DefaultSynchronizerFactory
                            .defaultCompactBlockRepository(coordinator.fsBlockDbRoot(zcashNetwork, alias), backend)

                    /**
                     * Downloader wraps the concurrently-built walletClient; built once and reused by both
                     * the (rarely used) init-state network fetch and the processor.
                     */
                    val downloaderDeferred =
                        async(Dispatchers.Default) {
                            DefaultSynchronizerFactory.defaultDownloader(walletClientDeferred.await(), blockStore)
                        }

                    val initializationState =
                        resolveWalletInitializationState(
                            downloaderProvider = { downloaderDeferred.await() },
                            fallbackTreeState = checkpointDeferred.await().treeState(),
                            sdkFlags = sdkFlags,
                            walletInitMode = walletInitMode
                        )

                    val repository =
                        DefaultSynchronizerFactory.defaultDerivedDataRepository(
                            context = applicationContext,
                            rustBackend = backend,
                            databaseFile = coordinator.dataDbFile(zcashNetwork, alias),
                            treeState = initializationState.treeState,
                            recoverUntil = initializationState.recoverUntil,
                            setup = setup,
                        )

                    val encoder = DefaultSynchronizerFactory.defaultEncoder(backend, saplingParamFetcher, repository)

                    walletClient = walletClientDeferred.await()

                    val downloader = downloaderDeferred.await()
                    val txManager = DefaultSynchronizerFactory.defaultTxManager(encoder, walletClient, sdkFlags)
                    val (preferenceProvider, pendingSubmitPlanStore) = prefsDeferred.await()
                    val transactionSubmitter =
                        EndpointTransactionSubmitter(
                            walletClientFactory = walletClientFactory,
                            sdkFlags = sdkFlags
                        )
                    val submitPlanExecutor = SubmitPlanExecutor(transactionSubmitter)
                    val processor =
                        DefaultSynchronizerFactory.defaultProcessor(
                            backend = backend,
                            birthdayHeight = birthday ?: zcashNetwork.saplingActivationHeight,
                            downloader = downloader,
                            repository = repository,
                            txManager = txManager,
                            sdkFlags = sdkFlags,
                            saplingParamFetcher = saplingParamFetcher,
                            pendingSubmitPlanStore = pendingSubmitPlanStore,
                            submitPlanExecutor = submitPlanExecutor
                        )

                    SdkSynchronizer.new(
                        context = context.applicationContext,
                        zcashNetwork = zcashNetwork,
                        alias = alias,
                        repository = repository,
                        txManager = txManager,
                        processor = processor,
                        backend = backend,
                        fastestServerFetcher =
                            FastestServerFetcher(
                                backend = backend,
                                network = processor.network,
                                walletClientFactory = walletClientFactory,
                                sdkFlags = sdkFlags
                            ),
                        fetchExchangeChangeUsd = fetchExchangeChangeUsd,
                        preferenceProvider = preferenceProvider,
                        lazyTorClient = lazyTorClient,
                        walletClient = walletClient,
                        walletClientFactory = walletClientFactory,
                        defaultSubmitEndpoint = lightWalletEndpoint,
                        pendingSubmitPlanStore = pendingSubmitPlanStore,
                        sdkFlags = sdkFlags
                    )
                } catch (e: CancellationException) {
                    walletClient?.dispose()
                    lazyTorClient?.dispose()
                    throw e
                } catch (e: Exception) {
                    walletClient?.dispose()
                    lazyTorClient?.dispose()
                    throw e
                }
            }
        }

        /**
         * Effectively the same as [new] although designed to be a blocking call with better
         * interoperability with Java clients.
         *
         * This is a blocking call, so it should not be called from the main thread.
         */
        @JvmStatic
        @Suppress("LongParameterList")
        fun newBlocking(
            alias: String = ZcashSdk.DEFAULT_ALIAS,
            birthday: BlockHeight?,
            context: Context,
            lightWalletEndpoint: LightWalletEndpoint,
            setup: AccountCreateSetup?,
            walletInitMode: WalletInitMode,
            zcashNetwork: ZcashNetwork,
            isTorEnabled: Boolean,
            isExchangeRateEnabled: Boolean
        ): CloseableSynchronizer =
            runBlocking {
                new(
                    alias = alias,
                    birthday = birthday,
                    context = context,
                    lightWalletEndpoint = lightWalletEndpoint,
                    setup = setup,
                    walletInitMode = walletInitMode,
                    zcashNetwork = zcashNetwork,
                    isTorEnabled = isTorEnabled,
                    isExchangeRateEnabled = isExchangeRateEnabled
                )
            }

        /**
         * Delete the databases associated with this wallet. This removes all compact blocks and
         * data derived from those blocks. Although most data can be regenerated by setting up a new
         * Synchronizer instance with the seed, there are two special cases where data is not retained:
         * 1. Outputs created with a `null` OVK
         * 2. The UA to which a transaction was sent (recovery from seed will only reveal the receiver, not the full UA)
         *
         * @param appContext the application context.
         * @param network the network associated with the data to be erased.
         * @param alias the alias used to create the local data.
         *
         * @return true when one of the associated files was found. False most likely indicates
         * that the wrong alias was provided.
         */
        suspend fun erase(
            appContext: Context,
            network: ZcashNetwork,
            alias: String = ZcashSdk.DEFAULT_ALIAS
        ): Boolean = SdkSynchronizer.erase(appContext, network, alias)
    }
}

private object UnavailableBroadcaster : Broadcaster {
    override suspend fun createProposedTransactions(
        proposal: Proposal,
        usk: UnifiedSpendingKey
    ): List<CreatedTransaction> = throw UnsupportedOperationException(
        "Synchronizer.broadcaster is unavailable for this Synchronizer implementation."
    )

    override suspend fun createTransactionFromPczt(
        pcztWithProofs: Pczt,
        pcztWithSignatures: Pczt
    ): List<CreatedTransaction> = throw UnsupportedOperationException(
        "Synchronizer.broadcaster is unavailable for this Synchronizer implementation."
    )

    override suspend fun submit(
        transaction: CreatedTransaction,
        endpoint: LightWalletEndpoint
    ): TransactionSubmitResult = throw UnsupportedOperationException(
        "Synchronizer.broadcaster is unavailable for this Synchronizer implementation."
    )
}

/**
 * Sealed class describing wallet initialization mode.
 *
 * Use [NewWallet] type if the seed was just created as part of a
 * new wallet initialization.
 *
 * Use [RestoreWallet] type if an existed wallet is initialized
 * from a restored seed with older birthday height.
 *
 * Use [ExistingWallet] type if the wallet is already initialized.
 */
sealed class WalletInitMode {
    data object NewWallet : WalletInitMode()

    data object RestoreWallet : WalletInitMode()

    data object ExistingWallet : WalletInitMode()
}

interface CloseableSynchronizer :
    Synchronizer,
    Closeable {
    /**
     * Closes the migration privacy gate without tearing the synchronizer down — used to decorrelate
     * host-initiated sync traffic from a migration broadcast. [syncBurst] refuses to run and no
     * transaction is resubmitted while paused; the instance, its poll loop and all its StateFlows
     * (status, balances, heights) stay alive, live and truthful. Idempotent.
     */
    fun pause()

    /** Reopens the gate after [pause], restarting a stopped engine when foregrounded. Idempotent. */
    fun resume()
}

/**
 * Validate that the alias doesn't contain malicious characters by enforcing simple rules which
 * permit the alias to be used as part of a file name for the preferences and databases. This
 * enables multiple wallets to exist on one device, which is also helpful for sweeping funds.
 *
 * @param alias the alias to validate.
 *
 * @throws IllegalArgumentException whenever the alias is not less than 100 characters or
 * contains something other than alphanumeric characters. Underscores and hyphens are allowed.
 */
private fun validateAlias(alias: String) {
    require(
        alias.length in ZcashSdk.ALIAS_MIN_LENGTH..ZcashSdk.ALIAS_MAX_LENGTH &&
            alias.all { it.isLetterOrDigit() || it == '_' || it == '-' }
    ) {
        "ERROR: Invalid alias ($alias). For security, the alias must be shorter than 100 " +
            "characters and only contain letters, digits, hyphens, and underscores."
    }
}

internal data class WalletInitializationState(
    val treeState: TreeState,
    val recoverUntil: BlockHeight?
)

/**
 * Resolves the [TreeState]/recover-until pair to use for wallet initialization, based on [walletInitMode].
 *
 * [WalletInitMode.ExistingWallet] is the normal cold-start case and never needs the network client, so it
 * does not invoke [downloaderProvider]. This lets DB init (repository/initDataDb) proceed without waiting
 * for the concurrently-built walletClient/downloader.
 */
internal suspend fun resolveWalletInitializationState(
    downloaderProvider: suspend () -> CompactBlockDownloader,
    fallbackTreeState: TreeState,
    sdkFlags: SdkFlags,
    walletInitMode: WalletInitMode,
    newWalletTreeStateTimeout: Duration = NEW_WALLET_TREE_STATE_FETCH_TIMEOUT
) = when (walletInitMode) {
    is RestoreWallet -> {
        WalletInitializationState(
            treeState = fallbackTreeState,
            recoverUntil = downloaderProvider().fetchRecoverUntil(sdkFlags)
        )
    }

    is WalletInitMode.NewWallet -> {
        WalletInitializationState(
            treeState =
                downloaderProvider().fetchNewWalletTreeState(
                    sdkFlags,
                    newWalletTreeStateTimeout
                ) ?: fallbackTreeState,
            recoverUntil = null
        )
    }

    is WalletInitMode.ExistingWallet -> {
        WalletInitializationState(
            treeState = fallbackTreeState,
            recoverUntil = null
        )
    }
}

private val NEW_WALLET_TREE_STATE_FETCH_TIMEOUT = 5.seconds

private suspend fun CompactBlockDownloader.fetchRecoverUntil(sdkFlags: SdkFlags): BlockHeight? =
    when (val response = getLatestBlockHeight(sdkFlags ifTor ServiceMode.UniqueTor)) {
        is Response.Success -> {
            Twig.info { "Chain tip for recovery until param fetched: ${response.result.value}" }
            runCatching { response.result.toBlockHeight() }.getOrNull()
        }

        is Response.Failure -> {
            Twig.error {
                "Chain tip fetch for recovery until failed with: ${response.toThrowable()}"
            }
            null
        }
    }

private suspend fun CompactBlockDownloader.fetchNewWalletTreeState(
    sdkFlags: SdkFlags,
    timeout: Duration
): TreeState? {
    var completed = false
    return withTimeoutOrNull(timeout) {
        fetchNewWalletTreeState(sdkFlags).also { completed = true }
    }.also {
        if (!completed) {
            Twig.warn {
                "Recent tree state fetch for new wallet timed out after $timeout, falling back to bundled checkpoint"
            }
        }
    }
}

private suspend fun CompactBlockDownloader.fetchNewWalletTreeState(
    sdkFlags: SdkFlags
): TreeState? =
    when (val heightResponse = getLatestBlockHeight(sdkFlags ifTor ServiceMode.UniqueTor)) {
        is Response.Success -> {
            fetchTreeStateNearTip(heightResponse.result, sdkFlags)
        }

        is Response.Failure -> {
            Twig.warn {
                "Chain tip fetch for new wallet failed with: " +
                    "${heightResponse.toThrowable()}, falling back to bundled checkpoint"
            }
            null
        }
    }

private suspend fun CompactBlockDownloader.fetchTreeStateNearTip(
    tipHeight: BlockHeightUnsafe,
    sdkFlags: SdkFlags
): TreeState? {
    val treeStateHeight =
        BlockHeightUnsafe(
            tipHeight.value - CompactBlockProcessor.MAX_REORG_SIZE
        )

    return when (
        val treeStateResponse =
            getTreeState(
                height = treeStateHeight,
                serviceMode = sdkFlags ifTor ServiceMode.UniqueTor
            )
    ) {
        is Response.Success -> {
            Twig.info {
                "New wallet: using reorg-safe tree state at height ${treeStateHeight.value}, tip ${tipHeight.value}"
            }
            TreeState.new(treeStateResponse.result)
        }

        is Response.Failure -> {
            Twig.warn {
                "Tree state fetch for new wallet failed with: " +
                    "${treeStateResponse.toThrowable()}, falling back to bundled checkpoint"
            }
            null
        }
    }
}
