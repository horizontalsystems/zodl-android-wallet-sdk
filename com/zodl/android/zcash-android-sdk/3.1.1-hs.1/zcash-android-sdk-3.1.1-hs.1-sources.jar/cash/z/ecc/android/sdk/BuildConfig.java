/**
 * Automatically generated file. DO NOT MODIFY
 */
package cash.z.ecc.android.sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "cash.z.ecc.android.sdk";
  public static final String BUILD_TYPE = "release";
  // Current library version
  public static final String LIBRARY_VERSION = "3.1.1-hs.1";
}
