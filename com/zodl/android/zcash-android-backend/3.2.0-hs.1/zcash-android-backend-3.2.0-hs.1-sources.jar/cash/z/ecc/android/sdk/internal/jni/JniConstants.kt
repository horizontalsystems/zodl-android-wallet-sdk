package cash.z.ecc.android.sdk.internal.jni

import cash.z.ecc.android.sdk.internal.model.JniAccount

/**
 * The number of bytes in the account UUID parameter. It's used e.g. in [JniAccount.accountUuid], or
 * [JniUnifiedSpendingKey.accountUuid]
 */
const val JNI_ACCOUNT_UUID_BYTES_SIZE = 16

/**
 * The number of bytes in the seed fingerprint parameter. It's used e.g. in [JniAccount.seedFingerprint]
 */
const val JNI_ACCOUNT_SEED_FP_BYTES_SIZE = 32

/**
 * The number of bytes in an HD-derived ZIP 32 key. It's used e.g. in [JniMetadataKey.sk]
 */
const val JNI_METADATA_KEY_SK_SIZE = 32

/**
 * The number of bytes in a chain code. It's used e.g. in [JniMetadataKey.chainCode]
 */
const val JNI_METADATA_KEY_CHAIN_CODE_SIZE = 32

/**
 * The number of bytes in a voting hotkey's opaque stored secret. It's used e.g. in
 * [cash.z.ecc.android.sdk.internal.model.voting.JniVotingHotkey.storedSecret]
 */
const val JNI_HOTKEY_STORED_SECRET_BYTES_SIZE = 64

/**
 * The number of bytes in a voting hotkey's raw Orchard address. It's used e.g. in
 * [cash.z.ecc.android.sdk.internal.model.voting.JniVotingHotkey.rawAddress]
 */
const val JNI_HOTKEY_RAW_ADDRESS_BYTES_SIZE = 43

/**
 * The number of bytes in a protocol field element crossing the voting JNI boundary.
 */
const val JNI_PROTOCOL_FIELD_BYTES_SIZE = 32

/**
 * The number of public input field elements emitted by delegation proof generation.
 */
const val JNI_DELEGATION_PUBLIC_INPUT_COUNT = 14

/**
 * The number of sibling hashes in a vote-authority-note witness.
 *
 * Must match VAN_WITNESS_PATH_DEPTH in backend-lib/src/main/rust/voting/helpers.rs.
 */
const val JNI_VAN_WITNESS_PATH_DEPTH = 24

/**
 * The number of encrypted vote shares produced by vote commitment generation.
 *
 * Must match VOTE_SHARE_COUNT in backend-lib/src/main/rust/voting/helpers.rs.
 */
const val JNI_VOTE_SHARE_COUNT = 16

/**
 * The number of governance nullifiers emitted by delegation proof generation.
 */
const val JNI_GOVERNANCE_NULLIFIER_COUNT = 5

/**
 * The number of bytes in an Orchard spend authorization signature.
 */
const val JNI_SPEND_AUTH_SIG_BYTES_SIZE = 64

/**
 * The number of bytes in the versioned Ironwood TX1 effecting data a delegation submission
 * carries to the vote-chain server in place of the local sighash. Must match
 * zcash_voting::tx1::TX1_EFFECTS_LEN (version byte + one Ironwood action's effecting data).
 */
const val JNI_TX1_EFFECTS_BYTES_SIZE = 821

/**
 * Voting JNI network id for testnet. Matches [cash.z.ecc.android.sdk.model.ZcashNetwork.ID_TESTNET].
 */
const val JNI_VOTING_NETWORK_ID_TESTNET = 0

/**
 * Voting JNI network id for mainnet. Matches [cash.z.ecc.android.sdk.model.ZcashNetwork.ID_MAINNET].
 */
const val JNI_VOTING_NETWORK_ID_MAINNET = 1
