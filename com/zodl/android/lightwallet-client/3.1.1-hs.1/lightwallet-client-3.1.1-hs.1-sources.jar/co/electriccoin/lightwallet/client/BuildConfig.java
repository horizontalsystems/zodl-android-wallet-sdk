/**
 * Automatically generated file. DO NOT MODIFY
 */
package co.electriccoin.lightwallet.client;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "co.electriccoin.lightwallet.client";
  public static final String BUILD_TYPE = "release";
}
